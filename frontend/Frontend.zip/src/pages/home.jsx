export default function Home() {
  return (
    <div style={{ backgroundColor: "red" }}>
      <div className="bg-blue-500 text-white p-10 text-4xl font-bold">
        If this is BLUE, Tailwind works
      </div>
    </div>
  );
}
