export default function RSVP() {
  return <h1>RSVP Page</h1>;
}
