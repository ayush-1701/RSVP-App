export default function AdminLogin() {
  return <h1>Admin Login</h1>;
}
