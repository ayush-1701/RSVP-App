export default function AdminDashboard() {
  return <h1>Admin Dashboard</h1>;
}
